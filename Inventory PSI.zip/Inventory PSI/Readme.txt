File *.Designer.vb yang bisa dibaca coding dengan notepad

*.zip program lengkap nya

-Terima Kasih-
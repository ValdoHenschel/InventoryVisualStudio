-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 12 Mei 2016 pada 20.26
-- Versi Server: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(99) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`customerID`, `name`, `email`, `contact`, `address`) VALUES
(1, 'budi', NULL, '120498', 'Jalan pisang 2'),
(2, 'anto', NULL, '12038947', 'Jalan Kelapa Sawit V'),
(3, 'Guntur', 'guntur@hehe.com', '0129385706', 'Jalan kebun lebat 5'),
(4, 'Herman', 'herman@hehe.com', '321136263', 'Jalan kebun lebat 5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `finished_goods`
--

CREATE TABLE `finished_goods` (
  `goodsID` int(11) NOT NULL,
  `finishedDate` date NOT NULL,
  `customerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `incoming_detail`
--

CREATE TABLE `incoming_detail` (
  `incomingID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `incoming_detail`
--

INSERT INTO `incoming_detail` (`incomingID`, `itemID`, `quantity`) VALUES
(1, 2, 12),
(1, 1, 16),
(2, 2, 8),
(2, 3, 9);

-- --------------------------------------------------------

--
-- Struktur dari tabel `incoming_item`
--

CREATE TABLE `incoming_item` (
  `incomingID` int(11) NOT NULL,
  `supplierID` int(11) NOT NULL,
  `arrivalDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `incoming_item`
--

INSERT INTO `incoming_item` (`incomingID`, `supplierID`, `arrivalDate`) VALUES
(1, 2, '2016-05-12'),
(2, 1, '2016-05-12'),
(4, 2, '2016-05-13'),
(5, 3, '2016-05-13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `outgoing_detail`
--

CREATE TABLE `outgoing_detail` (
  `outgoingID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `outgoing_item`
--

CREATE TABLE `outgoing_item` (
  `outgoingID` int(11) NOT NULL,
  `outgoingDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `raw_material`
--

CREATE TABLE `raw_material` (
  `itemID` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `raw_material`
--

INSERT INTO `raw_material` (`itemID`, `itemName`, `stock`) VALUES
(1, 'Kertas A4', 1000),
(2, 'Kertas Foto', 20),
(3, 'Tinta Warna', 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `supplierID` int(11) NOT NULL,
  `supplierName` varchar(50) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` varchar(99) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`supplierID`, `supplierName`, `email`, `contact`, `address`) VALUES
(1, 'PT Kertas Mantap', 'kertasmantap@huehue.com', '09841919512', 'Jalan Sarden 99'),
(2, 'CV Tinta Murni', 'tintamurni@huehue.com', '190238509690', 'Jalan Belida 12'),
(3, 'PT Maju Makmur', 'majumakmur@huehue.com', '31984912365', 'Jalan Tenggiri 53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `finished_goods`
--
ALTER TABLE `finished_goods`
  ADD PRIMARY KEY (`goodsID`),
  ADD KEY `customerID` (`customerID`);

--
-- Indexes for table `incoming_detail`
--
ALTER TABLE `incoming_detail`
  ADD KEY `itemID` (`itemID`),
  ADD KEY `incomingID` (`incomingID`);

--
-- Indexes for table `incoming_item`
--
ALTER TABLE `incoming_item`
  ADD PRIMARY KEY (`incomingID`),
  ADD KEY `supplierID` (`supplierID`);

--
-- Indexes for table `outgoing_detail`
--
ALTER TABLE `outgoing_detail`
  ADD KEY `outgoingID` (`outgoingID`),
  ADD KEY `itemID` (`itemID`);

--
-- Indexes for table `outgoing_item`
--
ALTER TABLE `outgoing_item`
  ADD PRIMARY KEY (`outgoingID`);

--
-- Indexes for table `raw_material`
--
ALTER TABLE `raw_material`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplierID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `finished_goods`
--
ALTER TABLE `finished_goods`
  MODIFY `goodsID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `incoming_item`
--
ALTER TABLE `incoming_item`
  MODIFY `incomingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `outgoing_item`
--
ALTER TABLE `outgoing_item`
  MODIFY `outgoingID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `raw_material`
--
ALTER TABLE `raw_material`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplierID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `finished_goods`
--
ALTER TABLE `finished_goods`
  ADD CONSTRAINT `finished_goods_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`);

--
-- Ketidakleluasaan untuk tabel `incoming_detail`
--
ALTER TABLE `incoming_detail`
  ADD CONSTRAINT `incoming_detail_ibfk_1` FOREIGN KEY (`incomingID`) REFERENCES `incoming_item` (`incomingID`),
  ADD CONSTRAINT `incoming_detail_ibfk_2` FOREIGN KEY (`itemID`) REFERENCES `raw_material` (`itemID`);

--
-- Ketidakleluasaan untuk tabel `incoming_item`
--
ALTER TABLE `incoming_item`
  ADD CONSTRAINT `incoming_item_ibfk_1` FOREIGN KEY (`supplierID`) REFERENCES `supplier` (`supplierID`);

--
-- Ketidakleluasaan untuk tabel `outgoing_detail`
--
ALTER TABLE `outgoing_detail`
  ADD CONSTRAINT `outgoing_detail_ibfk_1` FOREIGN KEY (`outgoingID`) REFERENCES `outgoing_item` (`outgoingID`),
  ADD CONSTRAINT `outgoing_detail_ibfk_2` FOREIGN KEY (`itemID`) REFERENCES `raw_material` (`itemID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
